'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { supabaseBrowser } from '@/lib/supabase/client'
// Cuando el jefe crea/modifica un servicio, la pantalla del trabajador se actualiza sola
export default function Live() {
  const router = useRouter()
  useEffect(() => {
    const sb = supabaseBrowser()
    const ch = sb.channel('live-services')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'services' }, () => router.refresh())
      .subscribe()
    return () => { sb.removeChannel(ch) }
  }, [router])
  return null
}
